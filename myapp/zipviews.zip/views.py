import os
import sys
import ctypes
import platform
import subprocess
import time
import socket
import hashlib
import json
import re
from datetime import datetime, timedelta

from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.contrib.auth import authenticate, login, get_user_model
from django.contrib import messages

User = get_user_model()

# ==============================================================================
# ⚙️ AEGIS SCANNING ENGINE - OPTIMIZED BUILT-IN UTILITIES
# ==============================================================================

def is_admin():
    """Check if the execution holds administrative privileges."""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() == 1
    except Exception:
        return False

def get_uptime():
    """Retrieve system boot time and calculate uptime efficiently."""
    try:
        import psutil
        uptime_seconds = time.time() - psutil.boot_time()
        days, remainder = divmod(uptime_seconds, 86400)
        hours, remainder = divmod(remainder, 3600)
        minutes, _ = divmod(remainder, 60)
        
        uptime_str = ""
        if days > 0: uptime_str += f"{int(days)}d "
        if hours > 0: uptime_str += f"{int(hours)}h "
        uptime_str += f"{int(minutes)}m"
        return uptime_str
    except Exception:
        return "Unknown"

def get_external_ip():
    """Retrieve the public IP address with a strict short timeout using native urllib."""
    import urllib.request
    try:
        req = urllib.request.Request(
            "https://api.ipify.org?format=json", 
            headers={'User-Agent': 'Aegis-Scanner/2.0'}
        )
        with urllib.request.urlopen(req, timeout=2.5) as response:
            return json.loads(response.read().decode()).get("ip", "Offline")
    except Exception:
        return "Offline / Unavailable"

def run_batch_powershell(commands_dict, timeout=6):
    """
    Executes multiple CIM/WMI commands in a single PowerShell process invocation.
    drastically lowering the execution overhead.
    """
    if platform.system() != "Windows":
        return {}
    
    # Construct a unified script building a single custom PSObject payload
    sb = ["$Output = @{}"]
    for key, cmd in commands_dict.items():
        sb.append(f"$Output.{key} = try {{ {cmd} | ConvertTo-Json -Compress }} catch {{ $null }}")
    sb.append("[Context]::Current.Format = 'Json'") # Precautionary structure alignment
    sb.append("$Output | ConvertTo-Json -Depth 4")
    
    unified_script = "; ".join(sb)
    
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", unified_script],
            capture_output=True, text=True, check=True, timeout=timeout
        )
        raw_output = json.loads(result.stdout.strip())
        
        # Decode nested compressed JSON strings
        final_data = {}
        for k, v in raw_output.items():
            if v:
                try:
                    final_data[k] = json.loads(v)
                except Exception:
                    final_data[k] = v
            else:
                final_data[k] = None
        return final_data
    except Exception:
        return {}

def profile_system_details():
    """Gather physical hardware, OS, and network specs."""
    import psutil
    details = {
        "hostname": socket.gethostname(),
        "os_name": platform.system(),
        "os_version": platform.version(),
        "os_release": platform.release(),
        "os_arch": platform.machine(),
        "cpu_model": platform.processor() or "Unknown CPU",
        "cpu_physical_cores": psutil.cpu_count(logical=False) or 0,
        "cpu_logical_cores": psutil.cpu_count(logical=True) or 0,
        "cpu_usage_pct": psutil.cpu_percent(interval=None),
        "ram_total_gb": round(psutil.virtual_memory().total / (1024**3), 2),
        "ram_used_gb": round(psutil.virtual_memory().used / (1024**3), 2),
        "ram_used_pct": psutil.virtual_memory().percent,
        "uptime": get_uptime(),
        "external_ip": get_external_ip(),
        "disks": [],
        "network_adapters": []
    }
    
    try:
        for part in psutil.disk_partitions(all=False):
            if os.name == 'nt' and 'cdrom' in part.opts:
                continue
            try:
                usage = psutil.disk_usage(part.mountpoint)
                details["disks"].append({
                    "device": part.device,
                    "mountpoint": part.mountpoint,
                    "fstype": part.fstype,
                    "total_gb": round(usage.total / (1024**3), 2),
                    "used_gb": round(usage.used / (1024**3), 2),
                    "used_pct": usage.percent
                })
            except (PermissionError, FileNotFoundError):
                continue
    except Exception:
        pass

    try:
        addrs = psutil.net_if_addrs()
        stats = psutil.net_if_stats()
        for interface, addr_list in addrs.items():
            is_up = stats[interface].isup if interface in stats else False
            ip_address = "No IP"
            mac_address = "No MAC"
            for addr in addr_list:
                if addr.family == socket.AF_INET:
                    ip_address = addr.address
                elif addr.family == psutil.AF_LINK:
                    mac_address = addr.address
            
            if ip_address != "No IP" or is_up:
                details["network_adapters"].append({
                    "interface": interface,
                    "status": "UP" if is_up else "DOWN",
                    "ip": ip_address,
                    "mac": mac_address
                })
    except Exception:
        pass

    return details

def get_extended_hardware_specs():
    """Retrieve highly detailed hardware stats, utilizing optimized batch queries."""
    import psutil
    specs = {
        "battery": {"percent": None, "power_plugged": None, "secsleft": None, "secsleft_formatted": "N/A", "status": "No battery detected"},
        "gpu": [],
        "motherboard": {"manufacturer": "Unknown", "product": "Unknown"},
        "bios": {"manufacturer": "Unknown", "name": "Unknown", "version": "Unknown"},
        "cpu_freq": {"current": 0, "min": 0, "max": 0},
        "cpu_per_core": [],
        "swap_memory": {"total_gb": 0, "used_gb": 0, "free_gb": 0, "used_pct": 0},
        "disk_io": {"read_mb": 0, "write_mb": 0},
        "net_io": {"sent_mb": 0, "recv_mb": 0}
    }
    
    # Fast metrics calculation
    try:
        battery = psutil.sensors_battery()
        if battery:
            secs = battery.secsleft
            secs_formatted = "Unlimited (Charging)" if secs in [psutil.POWER_TIME_UNLIMITED, -2] else ("Calculating..." if secs in [psutil.POWER_TIME_UNKNOWN, -1] else str(timedelta(seconds=secs)))
            specs["battery"] = {
                "percent": battery.percent, "power_plugged": battery.power_plugged, "secsleft": secs, "secsleft_formatted": secs_formatted,
                "status": f"{'Plugged In' if battery.power_plugged else 'On Battery'} ({battery.percent}%)"
            }
    except Exception: pass

    try:
        freq = psutil.cpu_freq()
        if freq:
            specs["cpu_freq"] = {"current": round(freq.current, 2), "min": round(freq.min, 2), "max": round(freq.max, 2)}
        specs["cpu_per_core"] = psutil.cpu_percent(percpu=True)
    except Exception: pass

    try:
        swap = psutil.swap_memory()
        specs["swap_memory"] = {"total_gb": round(swap.total / (1024**3), 2), "used_gb": round(swap.used / (1024**3), 2), "free_gb": round(swap.free / (1024**3), 2), "used_pct": swap.percent}
    except Exception: pass

    try:
        dio = psutil.disk_io_counters()
        if dio: specs["disk_io"] = {"read_mb": round(dio.read_bytes / (1024**2), 2), "write_mb": round(dio.write_bytes / (1024**2), 2)}
        nio = psutil.net_io_counters()
        if nio: specs["net_io"] = {"sent_mb": round(nio.bytes_sent / (1024**2), 2), "recv_mb": round(nio.bytes_recv / (1024**2), 2)}
    except Exception: pass

    # Batch execute native Windows diagnostics via consolidated Pipeline
    if platform.system() == "Windows":
        queries = {
            "gpu": "Get-CimInstance Win32_VideoController | Select-Object Name, AdapterRAM",
            "motherboard": "Get-CimInstance Win32_BaseBoard | Select-Object Manufacturer, Product",
            "bios": "Get-CimInstance Win32_BIOS | Select-Object Manufacturer, Name, Version"
        }
        batch_results = run_batch_powershell(queries)
        
        if "gpu" in batch_results and batch_results["gpu"]:
            gpus = batch_results["gpu"] if isinstance(batch_results["gpu"], list) else [batch_results["gpu"]]
            for g in gpus:
                vram_bytes = g.get("AdapterRAM", 0)
                specs["gpu"].append({
                    "name": g.get("Name", "Unknown GPU"),
                    "vram_gb": round(vram_bytes / (1024**3), 2) if vram_bytes else "Unknown"
                })
        if "motherboard" in batch_results and batch_results["motherboard"]:
            specs["motherboard"] = {
                "manufacturer": batch_results["motherboard"].get("Manufacturer", "Unknown"),
                "product": batch_results["motherboard"].get("Product", "Unknown")
            }
        if "bios" in batch_results and batch_results["bios"]:
            specs["bios"] = {
                "manufacturer": batch_results["bios"].get("Manufacturer", "Unknown"),
                "name": batch_results["bios"].get("Name", "Unknown"),
                "version": batch_results["bios"].get("Version", "Unknown")
            }

    return specs

def get_installed_security_softwares():
    """Query anti-malware assets via root\\SecurityCenter2 namespace pipelines."""
    products = []
    if platform.system() != "Windows":
        return products

    queries = {
        "av": "Get-CimInstance -Namespace root\\SecurityCenter2 -ClassName AntiVirusProduct | Select-Object displayName, productState, pathToSignedProductExe",
        "as": "Get-CimInstance -Namespace root\\SecurityCenter2 -ClassName AntiSpywareProduct | Select-Object displayName, productState, pathToSignedProductExe"
    }
    res = run_batch_powershell(queries)

    def parse_state(item, default_type):
        name = item.get("displayName", "Unknown")
        state = item.get("productState", 0)
        path = item.get("pathToSignedProductExe", "N/A")
        try:
            state_val = int(state)
            status_str = "Active / Enabled" if (state_val & 0x1000) != 0 else "Inactive / Disabled"
            sig_str = "Up-to-Date" if (state_val & 0x0010) == 0 else "Outdated"
        except Exception:
            status_str, sig_str = "Detected", "Unknown"
        return {"name": name, "type": default_type, "status": status_str, "signatures": sig_str, "path": path}

    for key, suite_type in [("av", "Antivirus Product"), ("as", "Antispyware Suite")]:
        if key in res and res[key]:
            items = res[key] if isinstance(res[key], list) else [res[key]]
            for entry in items:
                parsed = parse_state(entry, suite_type)
                if not any(p["name"].lower() == parsed["name"].lower() for p in products):
                    products.append(parsed)
                    
    return products

def audit_security_config():
    """Audit Firewall, Defender Antivirus, and UAC configuration markers on local targets."""
    audit = {
        "defender_enabled": "Unknown", "defender_realtime": "Unknown", "defender_signatures_up_to_date": "Unknown",
        "defender_controlled_folder": "Unknown", "smartscreen_enabled": "Unknown",
        "firewall_domain": "Unknown", "firewall_private": "Unknown", "firewall_public": "Unknown",
        "fw_domain_inbound": "Block", "fw_domain_outbound": "Allow",
        "fw_private_inbound": "Block", "fw_private_outbound": "Allow",
        "fw_public_inbound": "Block", "fw_public_outbound": "Allow",
        "uac_level": "Unknown", "uac_enabled": "Unknown"
    }
    if platform.system() != "Windows":
        return audit

    queries = {
        "defender": "Get-MpComputerStatus | Select-Object AMServiceEnabled, RealTimeProtectionEnabled, AntispywareSignatureAge",
        "preference": "Get-MpPreference | Select-Object EnableControlledFolderAccess, SmartScreenEnabled",
        "firewall": "Get-NetFirewallProfile | Select-Object Name, Enabled, DefaultInboundAction, DefaultOutboundAction"
    }
    res = run_batch_powershell(queries)

    # Decode target metrics maps
    if res.get("defender"):
        d = res["defender"]
        audit["defender_enabled"] = "Enabled" if d.get("AMServiceEnabled") else "Disabled"
        audit["defender_realtime"] = "Enabled" if d.get("RealTimeProtectionEnabled") else "Disabled"
        age = d.get("AntispywareSignatureAge")
        audit["defender_signatures_up_to_date"] = "Up to Date" if (age is not None and age <= 3) else f"Outdated ({age} days)" if age else "Unknown"

    if res.get("preference"):
        p = res["preference"]
        cfa = p.get("EnableControlledFolderAccess", 0)
        audit["defender_controlled_folder"] = "Enabled" if cfa == 1 else ("Audit Mode" if cfa == 2 else "Disabled")
        audit["smartscreen_enabled"] = p.get("SmartScreenEnabled", "Warn") or "Disabled"

    if res.get("firewall"):
        f_items = res["firewall"] if isinstance(res["firewall"], list) else [res["firewall"]]
        for f in f_items:
            n = f.get("Name", "").upper()
            state = "ON" if f.get("Enabled") else "OFF"
            ib = f.get("DefaultInboundAction", "Block")
            ob = f.get("DefaultOutboundAction", "Allow")
            if "DOMAIN" in n:
                audit["firewall_domain"], audit["fw_domain_inbound"], audit["fw_domain_outbound"] = state, ib, ob
            elif "PRIVATE" in n:
                audit["firewall_private"], audit["fw_private_inbound"], audit["fw_private_outbound"] = state, ib, ob
            elif "PUBLIC" in n:
                audit["firewall_public"], audit["fw_public_inbound"], audit["fw_public_outbound"] = state, ib, ob

    # Native registry fallback extraction for UAC parameters safely outside shell spawns
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System") as uac_key:
            enable_lua, _ = winreg.QueryValueEx(uac_key, "EnableLUA")
            prompt_admin, _ = winreg.QueryValueEx(uac_key, "ConsentPromptBehaviorAdmin")
            audit["uac_enabled"] = "Active" if enable_lua == 1 else "Disabled"
            
            if enable_lua == 0: audit["uac_level"] = "Disabled (Critical)"
            elif prompt_admin == 0: audit["uac_level"] = "Never Notify (Silent)"
            elif prompt_admin == 5: audit["uac_level"] = "Default (Secure Desktop)"
            elif prompt_admin == 2: audit["uac_level"] = "Always Notify"
            else: audit["uac_level"] = f"Custom ({prompt_admin})"
    except Exception:
        audit["uac_enabled"], audit["uac_level"] = "Unknown", "Registry Access Denied"

    return audit

def audit_user_accounts():
    """Audit target OS Local accounts for validation irregularities."""
    accounts = []
    if platform.system() != "Windows":
        return accounts

    res = run_batch_powershell({"users": "Get-CimInstance Win32_UserAccount | Select-Object Name, Disabled, LocalAccount, Lockout"})
    if res.get("users"):
        users = res["users"] if isinstance(res["users"], list) else [res["users"]]
        for u in users:
            name = u.get("Name", "Unknown")
            disabled = u.get("Disabled")
            status = "Disabled" if disabled else "Enabled"
            
            flagged = (name.lower() == "guest" and not disabled)
            accounts.append({
                "name": name, "status": status, "is_local": "Yes" if u.get("LocalAccount") else "No",
                "lockout": "Yes" if u.get("Lockout") else "No", "flagged": flagged,
                "risk_level": "Critical" if flagged else "Secure",
                "reasons": "Default Guest account is Enabled, posing security exposure rules." if flagged else ""
            })
    return accounts

def audit_network_shares():
    """Audit share exposure profiles."""
    shares = []
    if platform.system() != "Windows":
        return shares

    res = run_batch_powershell({"shares": "Get-CimInstance Win32_Share | Select-Object Name, Path, Type, Description"})
    if res.get("shares"):
        items = res["shares"] if isinstance(res["shares"], list) else [res["shares"]]
        for i in items:
            name = i.get("Name", "")
            path = i.get("Path", "N/A")
            share_type = i.get("Type", 0)
            is_admin_share = name.endswith('$') or share_type != 0
            
            flagged = not is_admin_share
            shares.append({
                "name": name, "path": path, "is_admin_share": "Yes" if is_admin_share else "No",
                "description": i.get("Description", ""), "flagged": flagged,
                "risk_level": "Warning" if flagged else "Secure",
                "reasons": f"Custom open share on route {path}. Verify ACLs." if flagged else ""
            })
    return shares

SYSTEM_MASQUERADE_LIST = ["svchost.exe", "lsass.exe", "explorer.exe", "services.exe", "winlogon.exe", "taskhostw.exe", "csrss.exe", "smss.exe", "wininit.exe", "spoolsv.exe", "conhost.exe"]
SUSPICIOUS_KEYWORDS = ["cheat", "hack", "miner", "cryptominer", "keylogger", "bypass", "malware", "keygen", "crack", "stealer", "trojan", "ransomware", "rat.exe"]

def scan_running_processes():
    """Scan all active execution paths looking for process deviations."""
    import psutil
    flagged_processes = []
    all_processes = []
    
    # Initialize processor reference context matrix across iteration frame
    for proc in psutil.process_iter(['pid', 'name', 'exe', 'memory_info', 'create_time', 'username']):
        try:
            pinfo = proc.info
            pid = pinfo['pid']
            name = pinfo['name'] or "Unknown"
            exe_path = pinfo['exe'] or "N/A"
            username = pinfo['username'] or "System"
            
            # Use non-blocking cpu check per runtime target slice safely
            try:
                cpu_pct = proc.cpu_percent(interval=None)
            except Exception:
                cpu_pct = 0.0
                
            mem_bytes = pinfo['memory_info'].rss if pinfo['memory_info'] else 0
            mem_mb = round(mem_bytes / (1024*1024), 2)
            
            create_time = "Unknown"
            if pinfo['create_time']:
                create_time = datetime.fromtimestamp(pinfo['create_time']).strftime('%Y-%m-%d %H:%M:%S')

            is_suspicious = False
            flag_reasons = []
            risk_level = "Secure"

            if cpu_pct > 80.0:
                is_suspicious, risk_level = True, "Warning"
                flag_reasons.append(f"High CPU utilization ({cpu_pct}%)")
            if mem_mb > 1500:
                is_suspicious, risk_level = True, "Warning"
                flag_reasons.append(f"High memory consumption ({mem_mb} MB)")

            if exe_path != "N/A":
                normalized_path = exe_path.lower()
                
                # Verify system binaries paths mappings patterns matching
                if name.lower() in SYSTEM_MASQUERADE_LIST:
                    if name.lower() == "explorer.exe":
                        if r"c:\windows" not in normalized_path:
                            is_suspicious, risk_level = True, "Critical"
                            flag_reasons.append(f"Masquerade: explorer.exe outside standard folder context ({exe_path})")
                    else:
                        if not (r"system32" in normalized_path or r"syswow64" in normalized_path):
                            is_suspicious, risk_level = True, "Critical"
                            flag_reasons.append(f"Masquerade: core binary execution outside System32 subsystem paths: {name}")

                # Temp or untrusted path verification loops
                for tp in [r"\appdata\local\temp", r"\windows\temp", r"\users\public", r"\downloads"]:
                    if tp in normalized_path:
                        is_suspicious, risk_level = True, "Critical"
                        flag_reasons.append(f"Execution path signature located inside unverified temporary boundary paths ({tp})")
                        break

                for kw in SUSPICIOUS_KEYWORDS:
                    if kw in name.lower() or kw in normalized_path:
                        is_suspicious, risk_level = True, "Critical"
                        flag_reasons.append(f"Suspicious flag verification matches target keyword tracking definition entry: [{kw}]")

            proc_data = {
                "pid": pid, "name": name, "path": exe_path, "cpu_pct": cpu_pct, "memory_mb": mem_mb,
                "username": username, "created": create_time, "risk_level": risk_level, "flagged": is_suspicious,
                "reasons": ", ".join(flag_reasons)
            }
            
            all_processes.append(proc_data)
            if is_suspicious:
                flagged_processes.append(proc_data)
                
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
            
    return all_processes, flagged_processes

def scan_startup_items():
    """Audit startup items from Registry vectors and safe workspace directory mapping queries."""
    startup_items = []
    if platform.system() != "Windows":
        return startup_items

    import winreg
    registry_paths = [
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", "HKCU Run"),
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\RunOnce", "HKCU RunOnce"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run", "HKLM Run"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\RunOnce", "HKLM RunOnce"),
    ]
    
    for hkey, subkey, location in registry_paths:
        try:
            with winreg.OpenKey(hkey, subkey, 0, winreg.KEY_READ) as key:
                info = winreg.QueryInfoKey(key)
                for i in range(info[1]):
                    name, val, _ = winreg.EnumValue(key, i)
                    exec_path = val.strip()
                    
                    # Enhanced extraction regex to handle paths with embedded parameters and spacing correctly
                    if exec_path.startswith('"'):
                        match = re.match(r'"([^"]+)"', exec_path)
                        resolved_path = match.group(1) if match else exec_path
                    else:
                        # Split by space *only* if it doesn't look like part of a long directory name missing quotes
                        resolved_path = exec_path.split(' -')[0].split(' /')[0].strip()
                        if not os.path.exists(resolved_path):
                            # Try matching legacy fallback split
                            potential_path = exec_path.split(' ')[0]
                            if os.path.exists(potential_path):
                                resolved_path = potential_path

                    file_exists = os.path.exists(resolved_path) if (resolved_path and not resolved_path.startswith('%')) else True
                    is_suspicious = False
                    flag_reasons = []
                    risk_level = "Secure"

                    if not file_exists:
                        is_suspicious, risk_level = True, "Warning"
                        flag_reasons.append("Orphaned item: pointing configuration source string binary missing on disc storage layout.")

                    if resolved_path:
                        norm_path = resolved_path.lower()
                        if any(x in norm_path for x in [r"\temp", r"\appdata\local\temp", r"\users\public"]):
                            is_suspicious, risk_level = True, "Critical"
                            flag_reasons.append("Untrusted location verification alert inside startup reference tree paths.")
                        
                        for kw in SUSPICIOUS_KEYWORDS:
                            if kw in norm_path:
                                is_suspicious, risk_level = True, "Critical"
                                flag_reasons.append(f"Startup execution target path flags signature entry match dictionary tracker keyword: {kw}")

                    startup_items.append({
                        "name": name, "command": val, "resolved_path": resolved_path or "N/A", "location": location,
                        "status": "Exists" if file_exists else "Missing", "risk_level": risk_level, "flagged": is_suspicious, "reasons": ", ".join(flag_reasons)
                    })
        except Exception:
            continue

    # Directory checks loops
    user_startup_dir = os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup")
    common_startup_dir = os.path.expandvars(r"%PROGRAMDATA%\Microsoft\Windows\Start Menu\Programs\Startup")
    
    for folder, loc_name in [(user_startup_dir, "User Startup Folder"), (common_startup_dir, "System Startup Folder")]:
        if os.path.exists(folder):
            try:
                for file_name in os.listdir(folder):
                    full_path = os.path.join(folder, file_name)
                    if os.path.isfile(full_path):
                        is_suspicious = False
                        flag_reasons = []
                        risk_level = "Secure"
                        
                        if file_name.count('.') > 1:
                            is_suspicious, risk_level = True, "Critical"
                            flag_reasons.append("Masked file metadata payload signature validation alert: Multi-extension disguise verification.")
                        
                        for kw in SUSPICIOUS_KEYWORDS:
                            if kw in file_name.lower():
                                is_suspicious, risk_level = True, "Critical"
                                flag_reasons.append(f"Directory link matching flagged keyword indicator: {kw}")

                        startup_items.append({
                            "name": file_name, "command": full_path, "resolved_path": full_path, "location": loc_name,
                            "status": "Exists", "risk_level": risk_level, "flagged": is_suspicious, "reasons": ", ".join(flag_reasons)
                        })
            except Exception: pass

    return startup_items

from django.shortcuts import render

def home(request):
    return render(request, 'home.html')